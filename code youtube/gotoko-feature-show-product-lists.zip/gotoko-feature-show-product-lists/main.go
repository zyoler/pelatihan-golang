package main

import "github.com/gieart87/gotoko/app"

func main() {
	app.Run()
}
