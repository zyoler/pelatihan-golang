package connection

import (
	"context"
	"log"

	"github.com/go-redis/redis/v8"
)

func ConnectRedis() *redis.Client {
	// Inisialisasi Redis Connection
	redis := redis.NewClient(&redis.Options{
		Addr:     "ec2-3-217-134-177.compute-1.amazonaws.com:17599",                   //hostname
		Password: "p0a639e9ccf0dafca1c8d23cc40cd6a34297712ddfd90f9ab59ab11e81f97c959", //password
		DB:       0,
	})

	ctx := context.Background()
	// test connection redis
	msg, err := redis.Ping(ctx).Result()

	// checked nil or return PONG from Ping(ctx)
	// return PONG if no argument is provided
	if err != nil || msg != "PONG" {
		log.Println("Error =>", err)
		log.Println("Redis Not Connect")
	} else {
		log.Println("Redis Connected")
	}
	return redis
}
