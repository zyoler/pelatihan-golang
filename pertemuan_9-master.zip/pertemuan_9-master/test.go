package main

// import "log"

// func main() {
// 	var Calc PerhitunganBangunDatar
// 	Calc = SisiPersegiPanjang{2, 5}
// 	log.Println("Luas Bangun Data = ", Calc.luas())
// }

// type PerhitunganBangunDatar interface {
// 	luas() int
// 	keliling() int
// }
// type SisiPersegiPanjang struct {
// 	sisiPanjang int
// 	sisiLebar   int
// }

// func (s SisiPersegiPanjang) luas() int {
// 	return s.sisiPanjang * s.sisiLebar
// }

// func (s SisiPersegiPanjang) keliling() int {
// 	return s.sisiLebar*2 + s.sisiPanjang
// }
