package main

import (
	"fmt"
	"net/http"
	"pertmuan_2/controller"

	"github.com/go-chi/chi"
)

func main() {
	r := chi.NewRouter()
	r.Get("/getdata", controller.GetData)
	r.Post("/postdata", controller.PostData)
	r.Delete("/delete-data-mhs/{id}", controller.DeleteData)
	r.Put("/update-data-mhs/{id}", controller.UpdateData)

	fmt.Println("Running Service")

	if err := http.ListenAndServe(":5000", r); err != nil {
		fmt.Println("Error Starting Service")
	}
	fmt.Println("Starting Services")
}
